package com.tut;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	try {
    		System.out.println( "Project Started.." );
            
            Configuration cfg = new Configuration();
            cfg.configure("com/tut/hibernate.cfg.xml");
            SessionFactory factory = cfg.buildSessionFactory();
            
            System.out.println(factory);
            System.out.println(factory.isClosed());
    	}
    	catch(Exception e){
    		System.out.println("Error");
    		e.printStackTrace();
    	}
        
    }
}
